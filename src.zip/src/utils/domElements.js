export const main = document.querySelector("main");
export const nav = document.querySelector("nav");
